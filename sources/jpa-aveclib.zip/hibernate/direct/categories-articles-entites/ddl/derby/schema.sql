
    alter table jpa05_hb_article 
        drop constraint FK3D957130ECCE8750;

    drop table jpa05_hb_article;

    drop table jpa05_hb_categorie;

    drop table hibernate_unique_key;

    create table jpa05_hb_article (
        id bigint not null,
        version integer not null,
        nom varchar(30),
        categorie_id bigint not null,
        primary key (id)
    );

    create table jpa05_hb_categorie (
        id bigint not null,
        version integer not null,
        nom varchar(30),
        primary key (id)
    );

    alter table jpa05_hb_article 
        add constraint FK3D957130ECCE8750 
        foreign key (categorie_id) 
        references jpa05_hb_categorie;

    create table hibernate_unique_key (
         next_hi integer 
    );

    insert into hibernate_unique_key values ( 0 );
