
    alter table jpa05_hb_article 
        drop constraint FK3D957130ECCE8750;

    drop table jpa05_hb_article;

    drop table jpa05_hb_categorie;

    drop generator hibernate_sequence;

    create table jpa05_hb_article (
        id numeric(18,0) not null,
        version integer not null,
        nom varchar(30),
        categorie_id numeric(18,0) not null,
        primary key (id)
    );

    create table jpa05_hb_categorie (
        id numeric(18,0) not null,
        version integer not null,
        nom varchar(30),
        primary key (id)
    );

    alter table jpa05_hb_article 
        add constraint FK3D957130ECCE8750 
        foreign key (categorie_id) 
        references jpa05_hb_categorie;

    create generator hibernate_sequence;
