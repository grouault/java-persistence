
    drop table jpa05_hb_article cascade constraints;

    drop table jpa05_hb_categorie cascade constraints;

    drop sequence hibernate_sequence;

    create table jpa05_hb_article (
        id number(19,0) not null,
        version number(10,0) not null,
        nom varchar2(30),
        categorie_id number(19,0) not null,
        primary key (id)
    );

    create table jpa05_hb_categorie (
        id number(19,0) not null,
        version number(10,0) not null,
        nom varchar2(30),
        primary key (id)
    );

    alter table jpa05_hb_article 
        add constraint FK3D957130ECCE8750 
        foreign key (categorie_id) 
        references jpa05_hb_categorie;

    create sequence hibernate_sequence;
