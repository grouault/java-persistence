
    alter table jpa06_hb_article 
        drop 
        foreign key FK4547168FECCE8750;

    alter table jpa06_hb_categorie_jpa06_hb_article 
        drop 
        foreign key FK8EBD825E777B5557;

    alter table jpa06_hb_categorie_jpa06_hb_article 
        drop 
        foreign key FK8EBD825E424C61C9;

    drop table if exists jpa06_hb_article;

    drop table if exists jpa06_hb_categorie;

    drop table if exists jpa06_hb_categorie_jpa06_hb_article;

    create table jpa06_hb_article (
        id bigint not null auto_increment,
        version integer not null,
        nom varchar(30),
        categorie_id bigint not null,
        primary key (id)
    ) ENGINE=InnoDB;

    create table jpa06_hb_categorie (
        id bigint not null auto_increment,
        version integer not null,
        nom varchar(30),
        primary key (id)
    ) ENGINE=InnoDB;

    create table jpa06_hb_categorie_jpa06_hb_article (
        jpa06_hb_categorie_id bigint not null,
        articles_id bigint not null,
        primary key (jpa06_hb_categorie_id, articles_id),
        unique (articles_id)
    ) ENGINE=InnoDB;

    alter table jpa06_hb_article 
        add index FK4547168FECCE8750 (categorie_id), 
        add constraint FK4547168FECCE8750 
        foreign key (categorie_id) 
        references jpa06_hb_categorie (id);

    alter table jpa06_hb_categorie_jpa06_hb_article 
        add index FK8EBD825E777B5557 (jpa06_hb_categorie_id), 
        add constraint FK8EBD825E777B5557 
        foreign key (jpa06_hb_categorie_id) 
        references jpa06_hb_categorie (id);

    alter table jpa06_hb_categorie_jpa06_hb_article 
        add index FK8EBD825E424C61C9 (articles_id), 
        add constraint FK8EBD825E424C61C9 
        foreign key (articles_id) 
        references jpa06_hb_article (id);
