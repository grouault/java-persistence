package entites;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="jpa10_hb_plat")
public class Plat implements java.io.Serializable {

	// champs
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(unique=true, length=50, nullable=false)
	private String nom;

	private boolean vegetarien;

	// constructeurs
	public Plat() {

	}

	public Plat(String name, boolean vegetarian) {
		setNom(name);
		setVegetarien(vegetarian);
	}

	// getters et setters
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String name) {
		this.nom = name;
	}

	public boolean isVegetarien() {
		return vegetarien;
	}

	public void setVegetarien(boolean vegetarian) {
		this.vegetarien = vegetarian;
	}

	// toString
	public String toString() {
		return "E[" + getNom() + "," + isVegetarien() + "]";
	}

}
