package entites;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "jpa10_hb_restaurant")
public class Restaurant implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	// champs
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(unique = true, length = 30, nullable = false)
	private String nom;

	@OneToOne(cascade = CascadeType.ALL)
	private Adresse adresse;

	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	@JoinTable(name = "jpa10_hb_restaurant_plat", inverseJoinColumns = @JoinColumn(name = "plat_id"))
	private Set<Plat> plats = new HashSet<Plat>();

	// constructeurs
	public Restaurant() {

	}

	public Restaurant(String name, Adresse address, Set<Plat> entrees) {
		setNom(name);
		setAdresse(address);
		setPlats(entrees);
	}

	// getters et setters
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String name) {
		this.nom = name;
	}

	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse address) {
		this.adresse = address;
	}

	public Set<Plat> getPlats() {
		return plats;
	}

	public void setPlats(Set<Plat> entrees) {
		this.plats = entrees;
	}

	// toString
	public String toString() {
		String signature = "R[" + getNom() + "," + getAdresse();
		for (Plat e : getPlats()) {
			signature += "," + e;
		}
		return signature + "]";
	}
}
