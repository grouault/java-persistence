package entites;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="jpa10_hb_adresse")
public class Adresse implements java.io.Serializable {
  
	// champs
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private long id;
  
  @Column(name = "NUMERO_RUE")
  private int numeroRue;
  
  @Column(name = "NOM_RUE", length=30, nullable=false)
  private String nomRue;
  
  // getters et setters
  public long getId() {
    return id;
  }
  
  public void setId(long id) {
    this.id = id;
  }
  
  public int getNumeroRue() {
    return numeroRue;
  }
  
  public void setNumeroRue(int streetNumber) {
    this.numeroRue = streetNumber;
  }
  
  public String getNomRue() {
    return nomRue;
  }
  
  public void setNomRue(String streetName) {
    this.nomRue = streetName;
  }
 
  // constructeurs
  public Adresse(int streetNumber, String streetName){
    setNumeroRue(streetNumber);
    setNomRue(streetName);
  }
  
  public Adresse(){
    
  }
  
  // toString
  public String toString(){
    return "A["+getNumeroRue()+","+getNomRue()+"]";
  }
}
