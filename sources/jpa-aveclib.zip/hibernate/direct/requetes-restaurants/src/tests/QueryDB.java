package tests;

import java.util.Iterator;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import entites.Adresse;
import entites.Plat;
import entites.Restaurant;

public class QueryDB {

	// Contexte de persistance
	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

	private static EntityManager em = emf.createEntityManager();

	public static void main(String[] args) {
		// d�but transaction
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		// supprimer les �l�ments de la table [restaurant]
		em.createNamedQuery("supprimer le contenu de la table restaurant").executeUpdate();
		// supprimer les �l�ments de la table [plat]
		em.createNamedQuery("supprimer le contenu de la table plat").executeUpdate();
		// cr�ation d'objets Address
		Adresse adr1 = new Adresse(10, "Main Street");
		Adresse adr2 = new Adresse(20, "Main Street");
		Adresse adr3 = new Adresse(123, "Dover Street");
		// cr�ation d'objets Entree
		Plat ent1 = new Plat("Hamburger", false);
		Plat ent2 = new Plat("Cheeseburger", false);
		Plat ent3 = new Plat("Tofu Stir Fry", true);
		Plat ent4 = new Plat("Vegetable Soup", true);
		// cr�ation d'objets Restaurant
		Restaurant restaurant1 = new Restaurant();
		restaurant1.setNom("Burger Barn");
		restaurant1.setAdresse(adr1);
		restaurant1.getPlats().add(ent1);
		restaurant1.getPlats().add(ent2);
		Restaurant restaurant2 = new Restaurant();
		restaurant2.setNom("Veggie Village");
		restaurant2.setAdresse(adr2);
		restaurant2.getPlats().add(ent3);
		restaurant2.getPlats().add(ent4);
		Restaurant restaurant3 = new Restaurant();
		restaurant3.setNom("Dover Diner");
		restaurant3.setAdresse(adr3);
		restaurant3.getPlats().add(ent1);
		restaurant3.getPlats().add(ent2);
		restaurant3.getPlats().add(ent4);
		// persistance des objets Restaurant
		em.persist(restaurant1);
		em.persist(restaurant2);
		em.persist(restaurant3);
		// fin transaction
		tx.commit();
		// dump base
		dumpDataBase();
		// fin EntityManager
		em.close();
		// fin EntityManagerFactory
		emf.close();
	}

	// affichage contenu de la base
	@SuppressWarnings("unchecked")
	private static void dumpDataBase() {
		// test2
		log("donn�es de la base");
		// d�but transaction
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		// affichages restaurants
		log("[restaurants]");
		for (Object restaurant : em.createNamedQuery("obtenir tous les restaurants").getResultList()) {
			System.out.println(restaurant);
		}
		// affichages adresses
		log("[adresses]");
		for (Object adresse : em.createNamedQuery("obtenir toutes les adresses").getResultList()) {
			System.out.println(adresse);
		}
		// affichages plats
		log("[plats]");
		for (Object plat : em.createNamedQuery("obtenir tous les plats").getResultList()) {
			System.out.println(plat);
		}
		// affichages liens restaurants <--> plats
		log("[restaurants/plats]");
		Iterator record = em.createNamedQuery("obtenir tous les restaurants avec leurs plats").getResultList().iterator();
		while (record.hasNext()) {
			Object[] currentRecord = (Object[]) record.next();
			System.out.format("[%s,%s]%n", currentRecord[0], currentRecord[1]);
		}
		log("[Liste des restaurants avec au moins un plat v�g�tarien]");
		for (Object r : em.createNamedQuery("obtenir les restaurants ayant au moins un plat vegetarien").getResultList()) {
			System.out.println(r);
		}
		// query
		log("[Liste des restaurants avec seulement des plats v�g�tariens]");
		for (Object r : em.createNamedQuery("obtenir les restaurants avec uniquement des plats vegetariens").getResultList()) {
			System.out.println(r);
		}
		// query
		log("[Liste des restaurants dans Dover Street]");
		for (Object r : em.createNamedQuery("obtenir les restaurants d'une certaine rue").setParameter("nomRue", "Dover Street").getResultList()) {
			System.out.println(r);
		}
		// query
		log("[Liste des restaurants ayant un plat de type burger]");
		record = em.createNamedQuery("obtenir les restaurants qui servent des burgers").getResultList().iterator();
		while (record.hasNext()) {
			Object[] currentRecord = (Object[]) record.next();
			System.out.format("[%s,%d,%s,%s]%n", currentRecord[0], currentRecord[1], currentRecord[2], currentRecord[3]);
		}
		// query
		log("[Plats de Veggie Village]");
		for (Object r : em.createNamedQuery("obtenir les plats du restaurant untel").setParameter("nomRestaurant", "Veggie Village").getResultList()) {
			System.out.println(r);
		}
		// fin transaction
		tx.commit();
	}

	// logs
	private static void log(String message) {
		System.out.println(" -----------" + message);
	}

}
