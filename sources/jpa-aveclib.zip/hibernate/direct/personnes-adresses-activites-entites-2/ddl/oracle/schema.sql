
    drop table jpa08_hb_activite cascade constraints;

    drop table jpa08_hb_adresse cascade constraints;

    drop table jpa08_hb_personne cascade constraints;

    drop table jpa08_hb_personne_activite cascade constraints;

    drop sequence hibernate_sequence;

    create table jpa08_hb_activite (
        id number(19,0) not null,
        version number(10,0) not null,
        nom varchar2(30) not null unique,
        primary key (id)
    );

    create table jpa08_hb_adresse (
        id number(19,0) not null,
        version number(10,0) not null,
        adr1 varchar2(30) not null,
        adr2 varchar2(30),
        adr3 varchar2(30),
        codePostal varchar2(5) not null,
        ville varchar2(20) not null,
        cedex varchar2(3),
        pays varchar2(20) not null,
        primary key (id)
    );

    create table jpa08_hb_personne (
        id number(19,0) not null,
        version number(10,0) not null,
        nom varchar2(30) not null unique,
        prenom varchar2(30) not null,
        datenaissance date not null,
        marie number(1,0) not null,
        nbenfants number(10,0) not null,
        adresse_id number(19,0) not null unique,
        primary key (id)
    );

    create table jpa08_hb_personne_activite (
        PERSONNE_ID number(19,0) not null,
        ACTIVITE_ID number(19,0) not null,
        primary key (PERSONNE_ID, ACTIVITE_ID)
    );

    alter table jpa08_hb_personne 
        add constraint FKA44B1E555FE379D0 
        foreign key (adresse_id) 
        references jpa08_hb_adresse;

    alter table jpa08_hb_personne_activite 
        add constraint FK5A6A55A5CD852024 
        foreign key (ACTIVITE_ID) 
        references jpa08_hb_activite;

    alter table jpa08_hb_personne_activite 
        add constraint FK5A6A55A568C7A284 
        foreign key (PERSONNE_ID) 
        references jpa08_hb_personne;

    create sequence hibernate_sequence;
