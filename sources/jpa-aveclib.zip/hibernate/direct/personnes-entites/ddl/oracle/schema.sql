
    drop table Personne cascade constraints;

    drop sequence hibernate_sequence;

    create table Personne (
        ID number(10,0) not null,
        VERSION number(10,0) not null,
        NOM varchar2(30) not null unique,
        PRENOM varchar2(30) not null,
        DATENAISSANCE date not null,
        MARIE number(1,0) not null,
        NBENFANTS number(10,0) not null,
        primary key (ID)
    );

    create sequence hibernate_sequence;
