
    drop table Personne;

    drop sequence hibernate_sequence;

    create table Personne (
        ID int4 not null,
        VERSION int4 not null,
        NOM varchar(30) not null unique,
        PRENOM varchar(30) not null,
        DATENAISSANCE date not null,
        MARIE bool not null,
        NBENFANTS int4 not null,
        primary key (ID)
    );

    create sequence hibernate_sequence;
