
    drop table Personne;

    create table Personne (
        ID int identity not null,
        VERSION int not null,
        NOM varchar(30) not null unique,
        PRENOM varchar(30) not null,
        DATENAISSANCE datetime not null,
        MARIE tinyint not null,
        NBENFANTS int not null,
        primary key (ID)
    );
