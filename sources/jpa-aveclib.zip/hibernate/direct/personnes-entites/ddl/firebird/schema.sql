
    drop table Personne;

    drop generator hibernate_sequence;

    create table Personne (
        ID integer not null,
        VERSION integer not null,
        NOM varchar(30) not null unique,
        PRENOM varchar(30) not null,
        DATENAISSANCE date not null,
        MARIE smallint not null,
        NBENFANTS integer not null,
        primary key (ID)
    );

    create generator hibernate_sequence;
