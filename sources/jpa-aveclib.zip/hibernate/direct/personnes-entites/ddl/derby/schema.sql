
    drop table Personne;

    drop table hibernate_unique_key;

    create table Personne (
        ID integer not null,
        VERSION integer not null,
        NOM varchar(30) not null unique,
        PRENOM varchar(30) not null,
        DATENAISSANCE date not null,
        MARIE smallint not null,
        NBENFANTS integer not null,
        primary key (ID)
    );

    create table hibernate_unique_key (
         next_hi integer 
    );

    insert into hibernate_unique_key values ( 0 );
