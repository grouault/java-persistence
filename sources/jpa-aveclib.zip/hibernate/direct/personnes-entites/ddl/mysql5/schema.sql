
    drop table if exists Personne;

    create table Personne (
        ID integer not null auto_increment,
        VERSION integer not null,
        NOM varchar(30) not null unique,
        PRENOM varchar(30) not null,
        DATENAISSANCE date not null,
        MARIE bit not null,
        NBENFANTS integer not null,
        primary key (ID)
    ) ENGINE=InnoDB;
