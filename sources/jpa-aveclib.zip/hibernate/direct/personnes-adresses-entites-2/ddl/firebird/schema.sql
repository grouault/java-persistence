
    alter table jpa04_hb_personne 
        drop constraint FKEA3F04515FE379D0;

    drop table jpa04_hb_adresse;

    drop table jpa04_hb_personne;

    drop generator hibernate_sequence;

    create table jpa04_hb_adresse (
        id numeric(18,0) not null,
        version integer not null,
        adr1 varchar(30) not null,
        adr2 varchar(30),
        adr3 varchar(30),
        codePostal varchar(5) not null,
        ville varchar(20) not null,
        cedex varchar(3),
        pays varchar(20) not null,
        primary key (id)
    );

    create table jpa04_hb_personne (
        id numeric(18,0) not null,
        version integer not null,
        nom varchar(30) not null unique,
        prenom varchar(30) not null,
        datenaissance date not null,
        marie smallint not null,
        nbenfants integer not null,
        adresse_id numeric(18,0) not null unique,
        primary key (id)
    );

    alter table jpa04_hb_personne 
        add constraint FKEA3F04515FE379D0 
        foreign key (adresse_id) 
        references jpa04_hb_adresse;

    create generator hibernate_sequence;
