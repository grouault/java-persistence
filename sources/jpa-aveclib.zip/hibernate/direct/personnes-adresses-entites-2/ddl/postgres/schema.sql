
    alter table jpa04_hb_personne 
        drop constraint FKEA3F04515FE379D0;

    drop table jpa04_hb_adresse;

    drop table jpa04_hb_personne;

    drop sequence hibernate_sequence;

    create table jpa04_hb_adresse (
        id int8 not null,
        version int4 not null,
        adr1 varchar(30) not null,
        adr2 varchar(30),
        adr3 varchar(30),
        codePostal varchar(5) not null,
        ville varchar(20) not null,
        cedex varchar(3),
        pays varchar(20) not null,
        primary key (id)
    );

    create table jpa04_hb_personne (
        id int8 not null,
        version int4 not null,
        nom varchar(30) not null unique,
        prenom varchar(30) not null,
        datenaissance date not null,
        marie bool not null,
        nbenfants int4 not null,
        adresse_id int8 not null unique,
        primary key (id)
    );

    alter table jpa04_hb_personne 
        add constraint FKEA3F04515FE379D0 
        foreign key (adresse_id) 
        references jpa04_hb_adresse;

    create sequence hibernate_sequence;
