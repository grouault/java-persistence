
    alter table jpa07_hb_personne 
        drop constraint FKB5C817D45FE379D0;

    alter table jpa07_hb_personne_activite 
        drop constraint FKD3E49B06CD852024;

    alter table jpa07_hb_personne_activite 
        drop constraint FKD3E49B0668C7A284;

    drop table jpa07_hb_activite;

    drop table jpa07_hb_adresse;

    drop table jpa07_hb_personne;

    drop table jpa07_hb_personne_activite;

    drop generator hibernate_sequence;

    create table jpa07_hb_activite (
        id numeric(18,0) not null,
        version integer not null,
        nom varchar(30) not null unique,
        primary key (id)
    );

    create table jpa07_hb_adresse (
        id numeric(18,0) not null,
        version integer not null,
        adr1 varchar(30) not null,
        adr2 varchar(30),
        adr3 varchar(30),
        codePostal varchar(5) not null,
        ville varchar(20) not null,
        cedex varchar(3),
        pays varchar(20) not null,
        primary key (id)
    );

    create table jpa07_hb_personne (
        id numeric(18,0) not null,
        version integer not null,
        nom varchar(30) not null unique,
        prenom varchar(30) not null,
        datenaissance date not null,
        marie smallint not null,
        nbenfants integer not null,
        adresse_id numeric(18,0) not null unique,
        primary key (id)
    );

    create table jpa07_hb_personne_activite (
        PERSONNE_ID numeric(18,0) not null,
        ACTIVITE_ID numeric(18,0) not null,
        primary key (PERSONNE_ID, ACTIVITE_ID)
    );

    alter table jpa07_hb_personne 
        add constraint FKB5C817D45FE379D0 
        foreign key (adresse_id) 
        references jpa07_hb_adresse;

    alter table jpa07_hb_personne_activite 
        add constraint FKD3E49B06CD852024 
        foreign key (ACTIVITE_ID) 
        references jpa07_hb_activite;

    alter table jpa07_hb_personne_activite 
        add constraint FKD3E49B0668C7A284 
        foreign key (PERSONNE_ID) 
        references jpa07_hb_personne;

    create generator hibernate_sequence;
