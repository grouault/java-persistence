
    drop table jpa02_hb_personne;

    drop sequence hibernate_sequence;

    create table jpa02_hb_personne (
        id int8 not null,
        version int4 not null,
        nom varchar(30) not null unique,
        prenom varchar(30) not null,
        datenaissance date not null,
        marie bool not null,
        nbenfants int4 not null,
        adr1 varchar(30) not null,
        adr2 varchar(30),
        adr3 varchar(30),
        codePostal varchar(5) not null,
        ville varchar(20) not null,
        cedex varchar(3),
        pays varchar(20) not null,
        primary key (id)
    );

    create sequence hibernate_sequence;
