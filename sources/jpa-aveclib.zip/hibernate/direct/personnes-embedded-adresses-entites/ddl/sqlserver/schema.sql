
    drop table jpa02_hb_personne;

    create table jpa02_hb_personne (
        id numeric(19,0) identity not null,
        version int not null,
        nom varchar(30) not null unique,
        prenom varchar(30) not null,
        datenaissance datetime not null,
        marie tinyint not null,
        nbenfants int not null,
        adr1 varchar(30) not null,
        adr2 varchar(30) null,
        adr3 varchar(30) null,
        codePostal varchar(5) not null,
        ville varchar(20) not null,
        cedex varchar(3) null,
        pays varchar(20) not null,
        primary key (id)
    );
