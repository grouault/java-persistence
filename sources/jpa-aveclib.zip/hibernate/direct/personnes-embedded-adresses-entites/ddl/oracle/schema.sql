
    drop table jpa02_hb_personne cascade constraints;

    drop sequence hibernate_sequence;

    create table jpa02_hb_personne (
        id number(19,0) not null,
        version number(10,0) not null,
        nom varchar2(30) not null unique,
        prenom varchar2(30) not null,
        datenaissance date not null,
        marie number(1,0) not null,
        nbenfants number(10,0) not null,
        adr1 varchar2(30) not null,
        adr2 varchar2(30),
        adr3 varchar2(30),
        codePostal varchar2(5) not null,
        ville varchar2(20) not null,
        cedex varchar2(3),
        pays varchar2(20) not null,
        primary key (id)
    );

    create sequence hibernate_sequence;
