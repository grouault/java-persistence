
    alter table jpa09_hb_personne 
        drop constraint FK92CE24D65FE379D0;

    alter table jpa09_hb_personne_activite 
        drop constraint FKE0F01044CD852024;

    alter table jpa09_hb_personne_activite 
        drop constraint FKE0F0104468C7A284;

    drop table jpa09_hb_activite;

    drop table jpa09_hb_adresse;

    drop table jpa09_hb_personne;

    drop table jpa09_hb_personne_activite;

    drop sequence hibernate_sequence;

    create table jpa09_hb_activite (
        id int8 not null,
        version int4 not null,
        nom varchar(30) not null unique,
        primary key (id)
    );

    create table jpa09_hb_adresse (
        id int8 not null,
        version int4 not null,
        adr1 varchar(30) not null,
        adr2 varchar(30),
        adr3 varchar(30),
        codePostal varchar(5) not null,
        ville varchar(20) not null,
        cedex varchar(3),
        pays varchar(20) not null,
        primary key (id)
    );

    create table jpa09_hb_personne (
        id int8 not null,
        version int4 not null,
        nom varchar(30) not null unique,
        prenom varchar(30) not null,
        datenaissance date not null,
        marie bool not null,
        nbenfants int4 not null,
        adresse_id int8 not null unique,
        primary key (id)
    );

    create table jpa09_hb_personne_activite (
        PERSONNE_ID int8 not null,
        ACTIVITE_ID int8 not null,
        primary key (PERSONNE_ID, ACTIVITE_ID)
    );

    alter table jpa09_hb_personne 
        add constraint FK92CE24D65FE379D0 
        foreign key (adresse_id) 
        references jpa09_hb_adresse;

    alter table jpa09_hb_personne_activite 
        add constraint FKE0F01044CD852024 
        foreign key (ACTIVITE_ID) 
        references jpa09_hb_activite;

    alter table jpa09_hb_personne_activite 
        add constraint FKE0F0104468C7A284 
        foreign key (PERSONNE_ID) 
        references jpa09_hb_personne;

    create sequence hibernate_sequence;
