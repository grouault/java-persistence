
    alter table jpa09_hb_personne 
        drop 
        foreign key FK92CE24D65FE379D0;

    alter table jpa09_hb_personne_activite 
        drop 
        foreign key FKE0F01044CD852024;

    alter table jpa09_hb_personne_activite 
        drop 
        foreign key FKE0F0104468C7A284;

    drop table if exists jpa09_hb_activite;

    drop table if exists jpa09_hb_adresse;

    drop table if exists jpa09_hb_personne;

    drop table if exists jpa09_hb_personne_activite;

    create table jpa09_hb_activite (
        id bigint not null auto_increment,
        version integer not null,
        nom varchar(30) not null unique,
        primary key (id)
    ) ENGINE=InnoDB;

    create table jpa09_hb_adresse (
        id bigint not null auto_increment,
        version integer not null,
        adr1 varchar(30) not null,
        adr2 varchar(30),
        adr3 varchar(30),
        codePostal varchar(5) not null,
        ville varchar(20) not null,
        cedex varchar(3),
        pays varchar(20) not null,
        primary key (id)
    ) ENGINE=InnoDB;

    create table jpa09_hb_personne (
        id bigint not null auto_increment,
        version integer not null,
        nom varchar(30) not null unique,
        prenom varchar(30) not null,
        datenaissance date not null,
        marie bit not null,
        nbenfants integer not null,
        adresse_id bigint not null unique,
        primary key (id)
    ) ENGINE=InnoDB;

    create table jpa09_hb_personne_activite (
        PERSONNE_ID bigint not null,
        ACTIVITE_ID bigint not null,
        primary key (PERSONNE_ID, ACTIVITE_ID)
    ) ENGINE=InnoDB;

    alter table jpa09_hb_personne 
        add index FK92CE24D65FE379D0 (adresse_id), 
        add constraint FK92CE24D65FE379D0 
        foreign key (adresse_id) 
        references jpa09_hb_adresse (id);

    alter table jpa09_hb_personne_activite 
        add index FKE0F01044CD852024 (ACTIVITE_ID), 
        add constraint FKE0F01044CD852024 
        foreign key (ACTIVITE_ID) 
        references jpa09_hb_activite (id);

    alter table jpa09_hb_personne_activite 
        add index FKE0F0104468C7A284 (PERSONNE_ID), 
        add constraint FKE0F0104468C7A284 
        foreign key (PERSONNE_ID) 
        references jpa09_hb_personne (id);
