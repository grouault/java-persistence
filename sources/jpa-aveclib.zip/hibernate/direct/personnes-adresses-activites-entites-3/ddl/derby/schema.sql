
    alter table jpa09_hb_personne 
        drop constraint FK92CE24D65FE379D0;

    alter table jpa09_hb_personne_activite 
        drop constraint FKE0F01044CD852024;

    alter table jpa09_hb_personne_activite 
        drop constraint FKE0F0104468C7A284;

    drop table jpa09_hb_activite;

    drop table jpa09_hb_adresse;

    drop table jpa09_hb_personne;

    drop table jpa09_hb_personne_activite;

    drop table hibernate_unique_key;

    create table jpa09_hb_activite (
        id bigint not null,
        version integer not null,
        nom varchar(30) not null unique,
        primary key (id)
    );

    create table jpa09_hb_adresse (
        id bigint not null,
        version integer not null,
        adr1 varchar(30) not null,
        adr2 varchar(30),
        adr3 varchar(30),
        codePostal varchar(5) not null,
        ville varchar(20) not null,
        cedex varchar(3),
        pays varchar(20) not null,
        primary key (id)
    );

    create table jpa09_hb_personne (
        id bigint not null,
        version integer not null,
        nom varchar(30) not null unique,
        prenom varchar(30) not null,
        datenaissance date not null,
        marie smallint not null,
        nbenfants integer not null,
        adresse_id bigint not null unique,
        primary key (id)
    );

    create table jpa09_hb_personne_activite (
        PERSONNE_ID bigint not null,
        ACTIVITE_ID bigint not null,
        primary key (PERSONNE_ID, ACTIVITE_ID)
    );

    alter table jpa09_hb_personne 
        add constraint FK92CE24D65FE379D0 
        foreign key (adresse_id) 
        references jpa09_hb_adresse;

    alter table jpa09_hb_personne_activite 
        add constraint FKE0F01044CD852024 
        foreign key (ACTIVITE_ID) 
        references jpa09_hb_activite;

    alter table jpa09_hb_personne_activite 
        add constraint FKE0F0104468C7A284 
        foreign key (PERSONNE_ID) 
        references jpa09_hb_personne;

    create table hibernate_unique_key (
         next_hi integer 
    );

    insert into hibernate_unique_key values ( 0 );
