package tests;

import java.text.ParseException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import service.IService;
import entites.Article;
import entites.Categorie;

public class InitDB {

	// couche service
	private static IService service;

	// constructeur
	public static void main(String[] args) throws ParseException {
		// configuration de l'application
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		// couche service
		service = (IService) ctx.getBean("service");
		// on vide la base
		clean();
		// on la remplit
		fill();
		// on v�rifie visuellement
		dumpCategories();
		dumpArticles();
	}

	// affichage contenu table categorie
	private static void dumpCategories() {
		System.out.format("[categories]%n");
		for (Categorie c : service.getAllCategories()) {
			System.out.println(c);
		}
	}

	// affichage contenu table Article
	private static void dumpArticles() {
		System.out.format("[articles]%n");
		for (Article a : service.getAllArticles()) {
			System.out.println(a);
		}
	}

	// remplissage tables
	public static void fill() throws ParseException {
		// cr�er trois cat�gories
		Categorie categorieA = new Categorie();
		categorieA.setNom("A");
		Categorie categorieB = new Categorie();
		categorieB.setNom("B");
		Categorie categorieC = new Categorie();
		categorieC.setNom("C");
		// cr�er 3 articles
		Article articleA1 = new Article();
		articleA1.setNom("A1");
		Article articleA2 = new Article();
		articleA2.setNom("A2");
		Article articleB1 = new Article();
		articleB1.setNom("B1");
		// les relier � leur cat�gorie
		articleA1.setCategorie(categorieA);
		categorieA.getArticles().add(articleA1);
		articleA2.setCategorie(categorieA);
		categorieA.getArticles().add(articleA2);
		articleB1.setCategorie(categorieB);
		categorieB.getArticles().add(articleB1);
		// persister les cat�gories et les articles associ�s
		service.saveCategoriesWithArticles(new Categorie[] { categorieA, categorieB, categorieC });
	}

	// supression �l�ments des tables
	public static void clean() {
		// on r�cup�re ttes les cat�gories
		List<Categorie> categories = service.getAllCategories();
		// � partir de l�, on supprime les cat�gories et les articles associ�s
		service.deleteCategoriesWithArticles(categories.toArray(new Categorie[categories.size()]));
	}
}
