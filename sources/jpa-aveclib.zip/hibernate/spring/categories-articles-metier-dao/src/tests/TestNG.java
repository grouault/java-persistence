package tests;

import java.text.ParseException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import service.IService;
import entites.Article;
import entites.Categorie;

public class TestNG {

	// couche service
	private IService service;

	@BeforeClass
	public void init() throws ParseException {
		// log
		log("init");
		// configuration de l'application
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		// couche service
		service = (IService) ctx.getBean("service");
		// on vide la base
		clean();
		// on la remplit
		fill();
		// on affiche
		dumpCategories();
		dumpArticles();
	}

	@AfterClass
	public void terminate() {
		// affichage tables
		System.out.println("--------------- contenu de la base");
		dumpCategories();
		dumpArticles();
		System.out.println("-----------------------------------");
	}

	// logs
	private void log(String message) {
		System.out.println("----------- " + message);
	}

	// remplissage tables
	public void fill() throws ParseException {
		// cr�er trois cat�gories
		Categorie categorieA = new Categorie();
		categorieA.setNom("A");
		Categorie categorieB = new Categorie();
		categorieB.setNom("B");
		Categorie categorieC = new Categorie();
		categorieC.setNom("C");
		// cr�er 3 articles
		Article articleA1 = new Article();
		articleA1.setNom("A1");
		Article articleA2 = new Article();
		articleA2.setNom("A2");
		Article articleB1 = new Article();
		articleB1.setNom("B1");
		// les relier � leur cat�gorie
		articleA1.setCategorie(categorieA);
		categorieA.getArticles().add(articleA1);
		articleA2.setCategorie(categorieA);
		categorieA.getArticles().add(articleA2);
		articleB1.setCategorie(categorieB);
		categorieB.getArticles().add(articleB1);
		// persister les cat�gories et les articles associ�s
		service.saveCategoriesWithArticles(new Categorie[] { categorieA, categorieB, categorieC });
	}

	// supression �l�ments des tables
	public void clean() {
		// on r�cup�re ttes les cat�gories
		List<Categorie> categories = service.getAllCategories();
		// � partir de l�, on supprime les cat�gories et les articles associ�s
		service.deleteCategoriesWithArticles(categories.toArray(new Categorie[categories.size()]));
	}

	// affichage contenu table categorie
	private void dumpCategories() {
		System.out.format("[categories]%n");
		for (Categorie c : service.getAllCategories()) {
			System.out.println(c);
		}
	}

	// affichage contenu table Article
	private void dumpArticles() {
		System.out.format("[articles]%n");
		for (Article a : service.getAllArticles()) {
			System.out.println(a);
		}
	}

	@Test()
	public void test01() {
		log("test01");
		dumpCategories();
		dumpArticles();
		// liste des cat�gories
		List<Categorie> categories = service.getAllCategories();
		assert 3 == categories.size();
		// liste des articles
		List<Article> articles = service.getAllArticles();
		assert 3 == articles.size();
	}

	@Test(dependsOnMethods = "test01")
	public void test02() {
		log("test02");
		// cat�gorie A
		List<Categorie> categories = service.getAllCategoriesWithNomLike("A%");
		assert 1 == categories.size();
		// categorie B
		categories = service.getAllCategoriesWithNomLike("B%");
		assert 1 == categories.size();
		// categorie C
		categories = service.getAllCategoriesWithNomLike("C%");
		assert 1 == categories.size();
		// articles A
		List<Article> articles = service.getAllArticlesWithNomLike("A%");
		assert 2 == articles.size();
		// articles B
		articles = service.getAllArticlesWithNomLike("B%");
		assert 1 == articles.size();
		// articles C
		articles = service.getAllArticlesWithNomLike("C%");
		assert 0 == articles.size();

	}

	@Test(dependsOnMethods = "test02")
	public void test03() {
		log("test03");
		// cat�gorie A
		List<Categorie> categories = service.getAllCategoriesWithNomLike("A%");
		assert 1 == categories.size();
		Categorie categorieA = categories.get(0);
		// articles associ�s
		List<Article> articles = service.getArticlesFromCategorie(categorieA.getId());
		// v�rification
		assert 2 == articles.size();
		// on ajoute un article
		Article articleA3 = new Article();
		articleA3.setNom("A3");
		// on le met dans la cat�gorie A
		articleA3.setCategorie(categorieA);
		// on le persiste
		service.saveArticle(articleA3);
		// articles associ�s � la cat�gorie A
		articles = service.getArticlesFromCategorie(categorieA.getId());
		// v�rification - il doit y en avoir 1 de plus
		assert 3 == articles.size();
		// articles A
		articles = service.getAllArticlesWithNomLike("A%");
		assert 3 == articles.size();
	}

	@Test(dependsOnMethods = "test03")
	public void test04() {
		log("test04");
		// suppression cat�gorie B avec les articles associ�s
		List<Categorie> categories = service.getAllCategoriesWithNomLike("B%");
		assert 1 == categories.size();
		Categorie categorieB = categories.get(0);
		service.deleteCategoriesWithArticles(new Categorie[] { categorieB });
		// v�rification
		categories = service.getAllCategoriesWithNomLike("B%");
		assert 0 == categories.size();
		// articles B
		List<Article> articles = service.getAllArticlesWithNomLike("B%");
		assert 0 == articles.size();
	}

	@Test(dependsOnMethods = "test04")
	public void test05() {
		log("test05");
		// cat�gorie A
		List<Categorie> categories = service.getAllCategoriesWithNomLike("A%");
		assert 1 == categories.size();
		Categorie categorieA = categories.get(0);
		// on modifie son nom
		categorieA.setNom("A+");
		service.updateCategorie(categorieA);
		// cat�gorie A
		categories = service.getAllCategoriesWithNomLike("A%");
		assert 1 == categories.size();
		categorieA = categories.get(0);
		assert "A+".equals(categorieA.getNom());
		// article A2
		List<Article> articles = service.getAllArticlesWithNomLike("A2%");
		assert 1 == articles.size();
		Article articleA2 = articles.get(0);
		// on modifie son nom
		articleA2.setNom("A2+");
		service.updateArticle(articleA2);
		// article A2
		articles = service.getAllArticlesWithNomLike("A2%");
		assert 1 == articles.size();
		articleA2 = articles.get(0);
		assert "A2+".equals(articleA2.getNom());
	}

	@Test(dependsOnMethods = "test05")
	public void test06() {
		log("test06");
		// cr�er deux nouvelles cat�gories
		Categorie categorieD = new Categorie();
		categorieD.setNom("D");
		Categorie categorieE = new Categorie();
		categorieD.setNom("E");
		// cr�er 1 nouvel article avec un nom existant (violation contrainte d'unicit�)
		Article articleD1 = new Article();
		articleD1.setNom("A1");
		// le relier � cat�gorie D
		articleD1.setCategorie(categorieD);
		categorieD.getArticles().add(articleD1);
		// on doit avoir une exception lors de la sauvegarde de article D1 et un rollback g�n�ral
		boolean erreur = false;
		try {
			// persister les cat�gories et les articles associ�s
			service.saveCategoriesWithArticles(new Categorie[] { categorieD, categorieE });
		} catch (RuntimeException e) {
			erreur = true;
		}
		// v�rifications : il y a du avoir une exception
		assert erreur;
		// et un rollback
		// cat�gorie D : elle ne doit pas exister
		List<Categorie> categories = service.getAllCategoriesWithNomLike("D%");
		assert 0 == categories.size();
		// cat�gorie E : elle ne doit pas exister
		categories = service.getAllCategoriesWithNomLike("E%");
		assert 0 == categories.size();
		// articles : il doit tjrs y avoir 3 articles
		List<Article> articles = service.getAllArticles();
		assert 3 == articles.size();
	}
}
