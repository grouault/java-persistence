package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entites.Article;
import entites.Categorie;

public class Dao implements IDao {

	@PersistenceContext
	private EntityManager em;

	// cat�gories

	public Categorie getCategorie(Long categorieId) {
		return em.find(Categorie.class, categorieId);
	}

	@SuppressWarnings("unchecked")
	public List<Categorie> getAllCategories() {
		return em.createQuery("select c from Categorie c").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Categorie> getAllCategoriesWithNomLike(String modeleNom) {
		return em.createQuery("select c from Categorie c where c.nom like :modele").setParameter("modele", modeleNom).getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Article> getArticlesFromCategorie(Long categorieId) {
		return em.createQuery("select a from Article a where a.categorie.id=:categorieId").setParameter("categorieId", categorieId).getResultList();
	}

	public Categorie updateCategorie(Categorie categorie) {
		return em.merge(categorie);
	}

	public Categorie saveCategorie(Categorie categorie) {
		em.persist(categorie);
		return categorie;
	}

	public void deleteCategorie(Long categorieId) {
		Categorie categorie = em.find(Categorie.class, categorieId);
		if (categorie == null) {
			throw new DaoException(30);
		}
		em.remove(categorie);
	}


	// articles

	public Article getArticle(Long articleId) {
		return em.find(Article.class, articleId);
	}

	@SuppressWarnings("unchecked")
	public List<Article> getAllArticles() {
		return em.createQuery("select a from Article a").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Article> getAllArticlesWithNomLike(String modeleNom) {
		return em.createQuery("select a from Article a where a.nom like :modele").setParameter("modele", modeleNom).getResultList();
	}

	public Article saveArticle(Article article) {
		em.persist(article);
		return article;
	}

	public Article updateArticle(Article article) {
		return em.merge(article);
	}

	public void deleteArticle(Long articleId) {
		Article article = em.find(Article.class, articleId);
		if (article == null) {
			throw new DaoException(20);
		}
		em.remove(article);
	}



}
