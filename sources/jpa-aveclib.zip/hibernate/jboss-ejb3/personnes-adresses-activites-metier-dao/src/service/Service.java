package service;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import dao.IDao;
import entites.Activite;
import entites.Adresse;
import entites.Personne;

//EJB sans �tat
@Stateless
public class Service implements IService {

	// couche [dao]
	@EJB
	private IDao dao;

	public IDao getDao() {
		return dao;
	}

	public void setDao(IDao dao) {
		this.dao = dao;
	}

	// cat�gories
	public Personne getPersonne(Long personneId) {
		return dao.getPersonne(personneId);
	}

	@SuppressWarnings("unchecked")
	public List<Personne> getAllPersonnes() {
		return dao.getAllPersonnes();
	}

	@SuppressWarnings("unchecked")
	public List<Personne> getAllPersonnesWithNomLike(String modeleNom) {
		return dao.getAllPersonnesWithNomLike(modeleNom);
	}

	@SuppressWarnings("unchecked")
	public List<Activite> getActivitesOfPersonne(Long personneId) {
		return dao.getActivitesOfPersonne(personneId);
	}

	public Personne updatePersonne(Personne personne) {
		return dao.updatePersonne(personne);
	}

	public Personne savePersonne(Personne personne) {
		return dao.savePersonne(personne);
	};

	public void deletePersonne(Long personneId) {
		dao.deletePersonne(personneId);
	}

	public void savePersonnesWithActivites(Personne[] personnes) {
		for (Personne personne : personnes) {
			dao.savePersonne(personne);
			for (Activite activite : personne.getActivites()) {
				dao.saveActivite(activite);
			}
		}
	}

	// activites
	public Activite getActivite(Long activiteId) {
		return dao.getActivite(activiteId);
	}

	@SuppressWarnings("unchecked")
	public List<Activite> getAllActivites() {
		return dao.getAllActivites();
	}

	@SuppressWarnings("unchecked")
	public List<Activite> getAllActivitesWithNomLike(String modeleNom) {
		return dao.getAllActivitesWithNomLike(modeleNom);
	};

	public Activite saveActivite(Activite activite) {
		return dao.saveActivite(activite);
	}

	public Activite updateActivite(Activite activite) {
		return dao.updateActivite(activite);
	}

	public void deleteActivite(Long activiteId) {
		dao.deleteActivite(activiteId);
	}

	public List<Personne> getPersonnesDoingActivite(Long activiteId) {
		return dao.getPersonnesDoingActivite(activiteId);
	}

	// adresses
	public List<Adresse> getAllAdresses() {
		return dao.getAllAdresses();
	}

}
