package tests;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.jboss.ejb3.embedded.EJB3StandaloneBootstrap;

import service.IService;
import entites.Activite;
import entites.Adresse;
import entites.Personne;

public class InitDB {

	// couche service
	private static IService service;

	// constructeur
	public static void main(String[] args) throws ParseException, NamingException {
		// on d�marre le conteneur EJB3 JBoss
		// les fichiers de configuration ejb3-interceptors-aop.xml et embedded-jboss-beans.xml sont exploit�s
		EJB3StandaloneBootstrap.boot(null);

		// Cr�ation des beans propres � l'application
		EJB3StandaloneBootstrap.deployXmlResource("META-INF/jboss-config.xml");

		// Deploy all EJBs found on classpath (slow, scans all)
		// EJB3StandaloneBootstrap.scanClasspath();

		// on d�ploie tous les EJB trouv�s dans le classpath de l'application
		EJB3StandaloneBootstrap.scanClasspath("bin".replace("/", File.separator));

		// On initialise le contexte JNDI. Le fichier jndi.properties est exploit�
		InitialContext initialContext = new InitialContext();

		// instanciation couche service
		service = (IService) initialContext.lookup("Service/local");
		// on vide la base
		clean();
		// on la remplit
		fill();
		// on v�rifie visuellement
		dumpPersonnes();
		dumpAdresses();
		dumpActivites();
		dumpPersonnesActivites();
	}

	// affichage contenu table personne
	private static void dumpPersonnes() {
		System.out.format("[personnes]%n");
		for (Personne p : service.getAllPersonnes()) {
			System.out.println(p);
		}
	}

	// affichage contenu table Adresse
	private static void dumpAdresses() {
		System.out.format("[adresses]%n");
		for (Adresse a : service.getAllAdresses()) {
			System.out.println(a);
		}
	}

	// affichage contenu table Activite
	private static void dumpActivites() {
		System.out.format("[activites]%n");
		for (Activite a : service.getAllActivites()) {
			System.out.println(a);
		}
	}

	// affichage contenu table Personne_Activite
	private static void dumpPersonnesActivites() {
		System.out.println("[personnes/activites]");
		for (Personne p : service.getAllPersonnes()) {
			for (Activite a : service.getActivitesOfPersonne(p.getId())) {
				System.out.format("[%s,%s]%n", p.getNom(), a.getNom());
			}
		}
	}

	// remplissage tables
	public static void fill() throws ParseException {
		// cr�ation activites
		Activite act1 = new Activite();
		act1.setNom("act1");
		Activite act2 = new Activite();
		act2.setNom("act2");
		Activite act3 = new Activite();
		act3.setNom("act3");
		// cr�ation personnes
		Personne p1 = new Personne("p1", "Paul", new SimpleDateFormat("dd/MM/yy").parse("31/01/2000"), true, 2);
		Personne p2 = new Personne("p2", "Sylvie", new SimpleDateFormat("dd/MM/yy").parse("05/07/2001"), false, 0);
		Personne p3 = new Personne("p3", "Sylvie", new SimpleDateFormat("dd/MM/yy").parse("05/07/2001"), false, 0);
		// cr�ation adresses
		Adresse adr1 = new Adresse("adr1", null, null, "49000", "Angers", null, "France");
		Adresse adr2 = new Adresse("adr2", "Les Mimosas", "15 av Foch", "49002", "Angers", "03", "France");
		Adresse adr3 = new Adresse("adr3", "x", "x", "x", "x", "x", "x");
		// associations personne <--> adresse
		p1.setAdresse(adr1);
		adr1.setPersonne(p1);
		p2.setAdresse(adr2);
		adr2.setPersonne(p2);
		p3.setAdresse(adr3);
		adr3.setPersonne(p3);
		// associations personnes <--> activites
		p1.getActivites().add(act1);
		p1.getActivites().add(act2);
		p2.getActivites().add(act1);
		p2.getActivites().add(act3);
		// persistance des personnes avec leurs activit�s
		service.savePersonnesWithActivites(new Personne[] { p1, p2, p3 });
	}

	// supression �l�ments des tables
	public static void clean() {
		// on supprime ttes les personnes et donc toutes les adresses
		for (Personne personne : service.getAllPersonnes()) {
			service.deletePersonne(personne.getId());
		}
		// on supprime ttes les activit�s
		for (Activite activite : service.getAllActivites()) {
			service.deleteActivite(activite.getId());
		}
	}
}
