package tests;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.jboss.ejb3.embedded.EJB3StandaloneBootstrap;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import service.IService;
import entites.Activite;
import entites.Adresse;
import entites.Personne;

public class TestNG {

	// couche service
	private IService service;

	@BeforeClass
	public void init() throws ParseException, NamingException {
		// log
		log("init");
		// on d�marre le conteneur EJB3 JBoss
		// les fichiers de configuration ejb3-interceptors-aop.xml et embedded-jboss-beans.xml sont exploit�s
		EJB3StandaloneBootstrap.boot(null);

		// Cr�ation des beans propres � l'application
		EJB3StandaloneBootstrap.deployXmlResource("META-INF/jboss-config.xml");

		// Deploy all EJBs found on classpath (slow, scans all)
		// EJB3StandaloneBootstrap.scanClasspath();

		// on d�ploie tous les EJB trouv�s dans le classpath de l'application
		EJB3StandaloneBootstrap.scanClasspath("bin".replace("/", File.separator));

		// On initialise le contexte JNDI. Le fichier jndi.properties est exploit�
		InitialContext initialContext = new InitialContext();

		// instanciation couche service
		service = (IService) initialContext.lookup("Service/local");
		// on vide la base
		clean();
		// on la remplit
		fill();
		// on affiche les tables
		dumpPersonnes();
		dumpAdresses();
		dumpActivites();
		dumpPersonnesActivites();
	}

	@AfterClass
	public void terminate() {
		// affichage tables
		System.out.println("--------------- contenu de la base");
		dumpPersonnes();
		dumpAdresses();
		dumpActivites();
		dumpPersonnesActivites();
		System.out.println("-----------------------------------");
	}

	// logs
	private void log(String message) {
		System.out.println("----------- " + message);
	}

	// remplissage tables
	public void fill() throws ParseException {
		// cr�ation activites
		Activite act1 = new Activite();
		act1.setNom("act1");
		Activite act2 = new Activite();
		act2.setNom("act2");
		Activite act3 = new Activite();
		act3.setNom("act3");
		// cr�ation personnes
		Personne p1 = new Personne("p1", "Paul", new SimpleDateFormat("dd/MM/yy").parse("31/01/2000"), true, 2);
		Personne p2 = new Personne("p2", "Sylvie", new SimpleDateFormat("dd/MM/yy").parse("05/07/2001"), false, 0);
		Personne p3 = new Personne("p3", "Sylvie", new SimpleDateFormat("dd/MM/yy").parse("05/07/2001"), false, 0);
		// cr�ation adresses
		Adresse adr1 = new Adresse("adr1", null, null, "49000", "Angers", null, "France");
		Adresse adr2 = new Adresse("adr2", "Les Mimosas", "15 av Foch", "49002", "Angers", "03", "France");
		Adresse adr3 = new Adresse("adr3", "x", "x", "x", "x", "x", "x");
		// associations personne <--> adresse
		p1.setAdresse(adr1);
		adr1.setPersonne(p1);
		p2.setAdresse(adr2);
		adr2.setPersonne(p2);
		p3.setAdresse(adr3);
		adr3.setPersonne(p3);
		// associations personnes <--> activites
		p1.getActivites().add(act1);
		p1.getActivites().add(act2);
		p2.getActivites().add(act1);
		p2.getActivites().add(act3);
		// persistance des personnes avec leurs activit�s
		service.savePersonnesWithActivites(new Personne[] { p1, p2, p3 });
	}

	// supression �l�ments des tables
	public void clean() {
		// on supprime ttes les personnes et donc toutes les adresses
		for (Personne personne : service.getAllPersonnes()) {
			service.deletePersonne(personne.getId());
		}
		// on supprime ttes les activit�s
		for (Activite activite : service.getAllActivites()) {
			service.deleteActivite(activite.getId());
		}
	}

	// affichage contenu table personne
	private void dumpPersonnes() {
		System.out.format("[personnes]%n");
		for (Personne c : service.getAllPersonnes()) {
			System.out.println(c);
		}
	}

	// affichage contenu table Adresse
	private void dumpAdresses() {
		System.out.format("[adresses]%n");
		for (Adresse a : service.getAllAdresses()) {
			System.out.println(a);
		}
	}

	// affichage contenu table Activite
	private void dumpActivites() {
		System.out.format("[activites]%n");
		for (Activite a : service.getAllActivites()) {
			System.out.println(a);
		}
	}

	// affichage contenu table Personne_Activite
	private void dumpPersonnesActivites() {
		System.out.println("[personnes/activites]");
		for (Personne p : service.getAllPersonnes()) {
			for (Activite a : service.getActivitesOfPersonne(p.getId())) {
				System.out.format("[%s,%s]%n", p.getNom(), a.getNom());
			}
		}
	}

	@Test()
	public void test01() {
		log("test01");
		// liste des personnes
		List<Personne> personnes = service.getAllPersonnes();
		assert 3 == personnes.size();
		// liste des adresses
		List<Adresse> adresses = service.getAllAdresses();
		assert 3 == adresses.size();
		// liste des activites
		List<Activite> activites = service.getAllActivites();
		assert 3 == activites.size();
	}

	@Test(dependsOnMethods = "test01")
	public void test02() {
		log("test02");
		// personne p1
		List<Personne> personnes = service.getAllPersonnesWithNomLike("p1%");
		assert 1 == personnes.size();
		// personne p2
		personnes = service.getAllPersonnesWithNomLike("p2%");
		assert 1 == personnes.size();
		// personne p3
		personnes = service.getAllPersonnesWithNomLike("p3%");
		assert 1 == personnes.size();
		// personne autre
		personnes = service.getAllPersonnesWithNomLike("b%");
		assert 0 == personnes.size();
		// activite act1
		List<Activite> activites = service.getAllActivitesWithNomLike("act1%");
		assert 1 == activites.size();
		// activite act2
		activites = service.getAllActivitesWithNomLike("act2%");
		assert 1 == activites.size();
		// activite act3
		activites = service.getAllActivitesWithNomLike("act3%");
		assert 1 == activites.size();
		// activite autre
		activites = service.getAllActivitesWithNomLike("b%");
		assert 0 == activites.size();
	}

	@Test(dependsOnMethods = "test02")
	public void test03() {
		log("test03");
		// personne p1
		List<Personne> personnes = service.getAllPersonnesWithNomLike("p1%");
		assert 1 == personnes.size();
		Personne p1 = personnes.get(0);
		// activites associ�s
		List<Activite> activitesP1 = service.getActivitesOfPersonne(p1.getId());
		// v�rification
		assert 2 == activitesP1.size();
		// on cr�e une nouvelle activite
		Activite act4 = new Activite();
		act4.setNom("act4");
		// qu'on persiste
		service.saveActivite(act4);
		// v�rification
		List<Activite> activites = service.getAllActivitesWithNomLike("act4%");
		assert 1 == activites.size();
		// on l'ajoute aux activit�s de la personne p1
		Set<Activite> activitesPersonneP1 = new HashSet<Activite>();
		for (Activite a : activitesP1) {
			activitesPersonneP1.add(a);
		}
		activitesPersonneP1.add(act4);
		p1.setActivites(activitesPersonneP1);
		// on persiste la personne
		service.updatePersonne(p1);
		// activites associ�es � la personne p1
		activites = service.getActivitesOfPersonne(p1.getId());
		// v�rification - il doit y en avoir 1 de plus
		assert 3 == activites.size();
	}

	@Test(dependsOnMethods = "test03")
	public void test04() {
		log("test04");
		// activit� act1
		List<Activite> activites = service.getAllActivitesWithNomLike("act1%");
		assert 1 == activites.size();
		Activite act1 = activites.get(0);
		// personnes faisant l'activit� act1
		List<Personne> personnesAct1 = service.getPersonnesDoingActivite(act1.getId());
		assert 2 == personnesAct1.size();
		// suppression personne P2
		List<Personne> personnes = service.getAllPersonnesWithNomLike("p2%");
		assert 1 == personnes.size();
		Personne p2 = personnes.get(0);
		service.deletePersonne(p2.getId());
		// v�rification
		personnes = service.getAllPersonnesWithNomLike("p2%");
		assert 0 == personnes.size();
		// activit�s act1 - la personne p2 faisait l'activit� act1
		personnesAct1 = service.getPersonnesDoingActivite(act1.getId());
		assert 1 == personnesAct1.size();
	}

	@Test(dependsOnMethods = "test04")
	public void test05() {
		log("test05");
		// personne p1
		List<Personne> personnes = service.getAllPersonnesWithNomLike("p1%");
		assert 1 == personnes.size();
		Personne p1 = personnes.get(0);
		// on modifie son nom
		p1.setNom("p1+");
		service.updatePersonne(p1);
		// v�rification
		personnes = service.getAllPersonnesWithNomLike("p1%");
		assert 1 == personnes.size();
		p1 = personnes.get(0);
		assert "p1+".equals(p1.getNom());
		// activit� act2
		List<Activite> activites = service.getAllActivitesWithNomLike("act2%");
		assert 1 == activites.size();
		Activite act2 = activites.get(0);
		// on modifie son nom
		act2.setNom("act2+");
		service.updateActivite(act2);
		// v�rification
		activites = service.getAllActivitesWithNomLike("act2%");
		assert 1 == activites.size();
		act2 = activites.get(0);
		assert "act2+".equals(act2.getNom());
	}

	@Test(dependsOnMethods = "test05")
	public void test06() throws ParseException {
		log("test06");
		// liste des activit�s
		List<Activite> activites = service.getAllActivites();
		int nbActivites = activites.size();
		// cr�er deux nouvelles personnes
		Personne p4 = new Personne("p4", "p4", new SimpleDateFormat("dd/MM/yy").parse("05/07/2001"), false, 0);
		Personne p5 = new Personne("p5", "p5", new SimpleDateFormat("dd/MM/yy").parse("05/07/2001"), false, 0);
		// cr�er 1 nouvelle activit� avec un nom existant (violation contrainte d'unicit�)
		Activite act4 = new Activite();
		act4.setNom("act1");
		// la personne p4 pratique l'activit� act4
		p4.getActivites().add(act4);
		// on doit avoir une exception lors de la sauvegarde de l'activit� act4 et un rollback g�n�ral
		boolean erreur = false;
		try {
			// persister les personnes et les activites
			service.savePersonnesWithActivites(new Personne[] { p4, p5 });
		} catch (RuntimeException e) {
			erreur = true;
		}
		// v�rifications : il y a du avoir une exception
		assert erreur;
		// et un rollback
		// personne p4 : elle ne doit pas exister
		List<Personne> personnes = service.getAllPersonnesWithNomLike("p4%");
		assert 0 == personnes.size();
		// personne p5 : elle ne doit pas exister
		personnes = service.getAllPersonnesWithNomLike("p5%");
		assert 0 == personnes.size();
		// le nbre d'activit�s n'a pas du changer
		activites = service.getAllActivites();
		assert nbActivites == activites.size();
	}

}
