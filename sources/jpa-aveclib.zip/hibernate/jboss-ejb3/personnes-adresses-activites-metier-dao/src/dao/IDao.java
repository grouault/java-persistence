package dao;

import java.util.List;

import entites.Activite;
import entites.Adresse;
import entites.Personne;

public interface IDao {

	// activit�s
	public Activite getActivite(Long activiteId);

	public List<Activite> getAllActivites();

	public Activite saveActivite(Activite activite);

	public Activite updateActivite(Activite activite);

	public void deleteActivite(Long activiteId);

	public List<Activite> getAllActivitesWithNomLike(String modeleNom);

	public List<Personne> getPersonnesDoingActivite(Long activiteId);

	// personnes
	public Personne getPersonne(Long personneId);

	public List<Personne> getAllPersonnes();

	public Personne savePersonne(Personne personne);

	public Personne updatePersonne(Personne personne);

	public void deletePersonne(Long personneId);

	public List<Personne> getAllPersonnesWithNomLike(String modeleNom);

	public List<Activite> getActivitesOfPersonne(Long personneId);

	// adresses
	public List<Adresse> getAllAdresses();

}
