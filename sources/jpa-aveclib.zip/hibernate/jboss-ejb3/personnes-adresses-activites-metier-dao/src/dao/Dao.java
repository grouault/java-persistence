package dao;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entites.Activite;
import entites.Adresse;
import entites.Personne;

@Stateless
public class Dao implements IDao {

	@PersistenceContext
	private EntityManager em;

	// personnes

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Personne getPersonne(Long categorieId) {
		return em.find(Personne.class, categorieId);
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Personne> getAllPersonnes() {
		return em.createQuery("select p from Personne p").getResultList();
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Personne> getAllPersonnesWithNomLike(String modeleNom) {
		return em.createQuery("select p from Personne p where p.nom like :modele").setParameter("modele", modeleNom).getResultList();
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Activite> getActivitesOfPersonne(Long personneId) {
		return em.createQuery("select a from Personne p join p.activites a where p.id=:personneId").setParameter("personneId", personneId)
				.getResultList();
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Personne updatePersonne(Personne personne) {
		return em.merge(personne);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Personne savePersonne(Personne personne) {
		em.persist(personne);
		return personne;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void deletePersonne(Long personneId) {
		Personne personne = em.find(Personne.class, personneId);
		if (personne == null) {
			throw new DaoException(30);
		}
		em.remove(personne);
	}

	// activit�s

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Activite getActivite(Long activiteId) {
		return em.find(Activite.class, activiteId);
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Activite> getAllActivites() {
		return em.createQuery("select a from Activite a").getResultList();
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Activite> getAllActivitesWithNomLike(String modeleNom) {
		return em.createQuery("select a from Activite a where a.nom like :modele").setParameter("modele", modeleNom).getResultList();
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Activite saveActivite(Activite activite) {
		em.persist(activite);
		return activite;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Activite updateActivite(Activite activite) {
		return em.merge(activite);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void deleteActivite(Long activiteId) {
		Activite article = em.find(Activite.class, activiteId);
		if (article == null) {
			throw new DaoException(20);
		}
		em.remove(article);
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Personne> getPersonnesDoingActivite(Long activiteId) {
		// la requ�te suivante marche avec Hibernate, pas avec Toplink qui refuse la navigation p.activites.id
		// return em.createQuery("select p from Personne p, Activite a where p.activites.id=a.id and a.id=:activiteId").setParameter("activiteId",
		// activiteId).getResultList();

		// la requ�te suivante est accept�e par les deux
		return em.createQuery("select p from Personne p join p.activites a where a.id=:activiteId").setParameter("activiteId", activiteId)
				.getResultList();
	}

	// adresses
	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Adresse> getAllAdresses() {
		return em.createQuery("select a from Adresse a").getResultList();
	}

}
