package dao;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entites.Personne;

@SuppressWarnings("unchecked")
@Stateless
public class Dao implements IDao {

	@PersistenceContext
	private EntityManager em;

	// supprimer une personne via son identifiant
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void deleteOne(Integer id) {
		Personne personne = em.find(Personne.class, id);
		if (personne == null) {
			throw new DaoException(2);
		}
		em.remove(personne);
	}

	@SuppressWarnings("unchecked")
	// obtenir toutes les personnes
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Personne> getAll() {
		return em.createQuery("select p from Personne p").getResultList();
	}

	// obtenir les personnes dont le nom correspond �un mod�le
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Personne> getAllLike(String modele) {
		return em.createQuery("select p from Personne p where p.nom like :modele")
				.setParameter("modele", modele).getResultList();
	}

	// obtenir une personne via son identifiant
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Personne getOne(Integer id) {
		return em.find(Personne.class, id);
	}

	// sauvegarder une personne
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Personne saveOne(Personne personne) {
		em.persist(personne);
		return personne;
	}

	// mettre � jour une personne
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Personne updateOne(Personne personne) {
		return em.merge(personne);
	}

}
