package dao;

import java.util.List;

import entites.Personne;

public interface IDao {
	// obtenir une personne via son identifiant
	public Personne getOne(Integer id);

	// obtenir toutes les personnes
	public List<Personne> getAll();

	// sauvegarder une personne
	public Personne saveOne(Personne personne);

	// mettre � jour une personne
	public Personne updateOne(Personne personne);

	// supprimer une personne via son identifiant
	public void deleteOne(Integer id);

	// obtenir les personnes dont le nom correspond �un mod�le
	public List<Personne> getAllLike(String modele);

}
