package service;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import dao.IDao;
import entites.Personne;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class Service implements IService {

	// couche [dao]
	@EJB
	private IDao dao;

	public IDao getDao() {
		return dao;
	}

	public void setDao(IDao dao) {
		this.dao = dao;
	}

	// supprimer plusieurs personnes � la fois
	public void deleteArray(Personne[] personnes) {
		for (Personne p : personnes) {
			dao.deleteOne(p.getId());
		}
	}

	// supprimer une personne via son identifiant
	public void deleteOne(Integer id) {
		dao.deleteOne(id);
	}

	// obtenir toutes les personnes
	public List<Personne> getAll() {
		return dao.getAll();
	}

	// obtenir les personnes dont le nom correspond �un mod�le
	public List<Personne> getAllLike(String modele) {
		return dao.getAllLike(modele);
	}

	// obtenir une personne via son identifiant
	public Personne getOne(Integer id) {
		return dao.getOne(id);
	}

	// sauvegarder plusieurs personnes � la fois
	public Personne[] saveArray(Personne[] personnes) {
		Personne[] personnes2 = new Personne[personnes.length];
		for (int i = 0; i < personnes.length; i++) {
			personnes2[i] = dao.saveOne(personnes[i]);
		}
		return personnes2;
	}

	// sauvegarder une personne
	public Personne saveOne(Personne personne) {
		return dao.saveOne(personne);
	}

	// metre � jour plusieurs personnes � la fois
	public Personne[] updateArray(Personne[] personnes) {
		Personne[] personnes2 = new Personne[personnes.length];
		for (int i = 0; i < personnes.length; i++) {
			personnes2[i] = dao.updateOne(personnes[i]);
		}
		return personnes2;
	}

	// mettre � jour une personne
	public Personne updateOne(Personne personne) {
		return dao.updateOne(personne);
	}

}
