package service;

import java.util.List;

import entites.Personne;

public interface IService {
	public Personne getOne(Integer id);

	public List<Personne> getAll();

	public Personne saveOne(Personne personne);

	public Personne updateOne(Personne personne);

	public void deleteOne(Integer id);

	public List<Personne> getAllLike(String modele);

	public void deleteArray(Personne[] personnes);

	public Personne[] saveArray(Personne[] personnes);

	public Personne[] updateArray(Personne[] personnes);

}
