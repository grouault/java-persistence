package tests;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.jboss.ejb3.embedded.EJB3StandaloneBootstrap;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import entites.Personne;

import service.IService;

public class TestNG {

	// couche service
	private IService service = null;

	@BeforeClass
	public void init() throws NamingException, ParseException {
		// log
		log("init");
		// on d�marre le conteneur EJB3 JBoss
		// les fichiers de configuration ejb3-interceptors-aop.xml et embedded-jboss-beans.xml sont exploit�s
		EJB3StandaloneBootstrap.boot(null);

		// Cr�ation des beans propres � l'application
		EJB3StandaloneBootstrap.deployXmlResource("META-INF/jboss-config.xml");

		// Deploy all EJBs found on classpath (slow, scans all)
		// EJB3StandaloneBootstrap.scanClasspath();

		// on d�ploie tous les EJB trouv�s dans le classpath de l'application
		EJB3StandaloneBootstrap.scanClasspath("bin".replace("/", File.separator));

		// On initialise le contexte JNDI. Le fichier jndi.properties est exploit�
		InitialContext initialContext = new InitialContext();

		// instanciation couche service
		service = (IService) initialContext.lookup("Service/local");
		// on vide la base
		clean();
		// on la remplit
		fill();
		// on v�rifie visuellement
		dumpPersonnes();
	}

	@AfterClass
	public void terminate() {
		// log
		log("terminate");
		// on arr�te le conteneur Ejb
		EJB3StandaloneBootstrap.shutdown();
	}

	@BeforeMethod
	public void setUp() throws ParseException {
		// on vide la base
		clean();
		// on la remplit
		fill();
	}

	// logs
	private void log(String message) {
		System.out.println("----------- " + message);
	}

	// affichage contenu table
	private void dumpPersonnes() {
		System.out.format("[personnes]%n");
		for (Personne p : service.getAll()) {
			System.out.println(p);
		}
	}

	// remplissage table
	public void fill() throws ParseException {
		// cr�ation personnes
		Personne p1 = new Personne("p1", "Paul", new SimpleDateFormat("dd/MM/yy").parse("31/01/2000"), true, 2);
		Personne p2 = new Personne("p2", "Sylvie", new SimpleDateFormat("dd/MM/yy").parse("05/07/2001"), false, 0);
		// qu'on sauvegarde
		service.saveArray(new Personne[] { p1, p2 });
	}

	// supression �l�ments de la table
	public void clean() {
		for (Personne p : service.getAll()) {
			service.deleteOne(p.getId());
		}
	}

	@Test()
	public void test01() {
		log("test1");
		dumpPersonnes();
		// liste des personnes
		List<Personne> personnes = service.getAll();
		assert 2 == personnes.size();
	}

	@Test(dependsOnMethods = "test01")
	public void test02() {
		log("test2");
		// recherche de personnes par leur nom
		List<Personne> personnes = service.getAllLike("p1%");
		assert 1 == personnes.size();
		Personne p1 = personnes.get(0);
		assert "Paul".equals(p1.getPrenom());
	}

	@Test(dependsOnMethods = "test02")
	public void test03() throws ParseException {
		log("test3");
		// cr�ation d'une nouvelle personne
		Personne p3 = new Personne("p3", "x", new SimpleDateFormat("dd/MM/yy").parse("05/07/2001"), false, 0);
		// on la persiste
		service.saveOne(p3);
		// on la redemande
		Personne loadedp3 = service.getOne(p3.getId());
		// on l'affiche
		System.out.println(loadedp3);
		// v�rification
		assert "p3".equals(loadedp3.getNom());
	}

	@Test(dependsOnMethods = "test03")
	public void test04() throws ParseException {
		log("test4");
		// on charge la personne p1
		List<Personne> personnes = service.getAllLike("p1%");
		Personne p1 = personnes.get(0);
		// on l'affiche
		System.out.println(p1);
		// on v�rifie
		assert "p1".equals(p1.getNom());
		int version1 = p1.getVersion();
		// on modifie le pr�nom
		p1.setPrenom("x");
		// on sauvegarde
		service.updateOne(p1);
		// on recharge
		p1 = service.getOne(p1.getId());
		// on l'affiche
		System.out.println(p1);
		// on v�rifie que la version a �t� incr�ment�e
		assert (version1 + 1) == p1.getVersion();

	}

	@Test(dependsOnMethods = "test04")
	public void test05() {
		log("test5");
		// on charge la personne p2
		List<Personne> personnes = service.getAllLike("p2%");
		Personne p2 = personnes.get(0);
		// on l'affiche
		System.out.println(p2);
		// on v�rifie
		assert "p2".equals(p2.getNom());
		// on supprime la personne p2
		service.deleteOne(p2.getId());
		// on la recharge
		p2 = service.getOne(p2.getId());
		// on v�rifie qu'on a obtenu un pointeur null
		assert null == p2;
		// on affiche la table
		dumpPersonnes();
	}

	@Test(dependsOnMethods = "test05")
	public void test06() throws ParseException {
		log("test6");
		// on cr�e un tableau de 2 personnes de m�me nom (enfreint la r�gle d'unicit� du nom)
		Personne[] personnes = { new Personne("p3", "x", new SimpleDateFormat("dd/MM/yy").parse("31/01/2000"), true, 2),
				new Personne("p3", "x", new SimpleDateFormat("dd/MM/yy").parse("31/01/2000"), true, 2) };
		// on sauvegarde ce tableau - on doit obtenir une exception et un rollback
		boolean erreur = false;
		try {
			service.saveArray(personnes);
		} catch (RuntimeException e) {
			erreur = true;
		}
		// dump
		dumpPersonnes();
		// v�rifications
		assert erreur;
		// recherche personne de nom p4
		List<Personne> personnesp4 = service.getAllLike("p4%");
		assert 0 == personnesp4.size();
		// dump
		dumpPersonnes();
	}

	@Test(dependsOnMethods = "test06")
	public void test07() {
		log("test7");
		// test optimistic locking
		// on charge la personne p1
		List<Personne> personnes = service.getAllLike("p1%");
		Personne p1 = personnes.get(0);
		// on l'affiche
		System.out.println(p1);
		// on augmente son nbre d'enfants
		int nbEnfants1 = p1.getNbenfants();
		p1.setNbenfants(nbEnfants1 + 1);
		// on sauvegarde p1
		Personne newp1 = service.updateOne(p1);
		assert (nbEnfants1 + 1) == newp1.getNbenfants();
		System.out.println(newp1);
		// on sauvegarde une deuxi�me fois - on doit avoir une exception car p1 n'a plus la bonne version
		// c'est newp1 qui l'a
		boolean erreur = false;
		try {
			service.updateOne(p1);
		} catch (RuntimeException e) {
			erreur = true;
		}
		// v�rification
		assert erreur;
		// on augmente le nbre d'enfants de newp1
		int nbEnfants2 = newp1.getNbenfants();
		newp1.setNbenfants(nbEnfants2 + 1);
		// on sauvegarde newp1
		service.updateOne(newp1);
		// on recharge
		p1 = service.getOne(p1.getId());
		// on v�rifie
		assert (nbEnfants1 + 2) == p1.getNbenfants();
		System.out.println(p1);
	}

	@Test(dependsOnMethods = "test07")
	public void test08() {
		log("test8");
		// test rollback sur updateArray
		// on charge la personne p1
		List<Personne> personnes = service.getAllLike("p1%");
		Personne p1 = personnes.get(0);
		// on l'affiche
		System.out.println(p1);
		// on augmente son nbre d'enfants
		int nbEnfants1 = p1.getNbenfants();
		p1.setNbenfants(nbEnfants1 + 1);
		// on sauvegarde 2 modifications dont la 2i�me doit �chouer (personne inconnue)
		// � cause de la transaction, les deux doivent alors �tre annul�es
		boolean erreur = false;
		try {
			service.updateArray(new Personne[] { p1, new Personne() });
		} catch (RuntimeException e) {
			erreur = true;
		}
		// v�rifications
		assert erreur;
		// on recharge la personne p1
		personnes = service.getAllLike("p1%");
		p1 = personnes.get(0);
		// son nbre d'enfants n'a pas du changer
		assert nbEnfants1 == p1.getNbenfants();
	}

	@Test(dependsOnMethods = "test08")
	public void test09() {
		log("test9");
		// test rollback sur deleteArray
		// dump
		dumpPersonnes();
		// on charge la personne p1
		List<Personne> personnes = service.getAllLike("p1%");
		Personne p1 = personnes.get(0);
		// on l'affiche
		System.out.println(p1);
		// on fait 2 suppressions dont la 2i�me doit �chouer (personne inconnue)
		// � cause de la transaction, les deux doivent alors �tre annul�es
		boolean erreur = false;
		try {
			service.deleteArray(new Personne[] { p1, new Personne() });
		} catch (RuntimeException e) {
			erreur = true;
		}
		// v�rifications
		assert erreur;
		// on recharge la personne p1
		personnes = service.getAllLike("p1%");
		// v�rification
		assert 1 == personnes.size();
		// dump
		dumpPersonnes();
	}

	// optimistic locking - acc�s multi-threads
	@Test(dependsOnMethods = "test09")
	public void test10() throws Exception {
		log("test10");
		// ajout d'une personne
		Personne p3 = new Personne("X", "X", new SimpleDateFormat("dd/MM/yyyy").parse("01/02/2006"), true, 0);
		service.saveOne(p3);
		int id3 = p3.getId();
		// cr�ation de N threads de mise � jour du nombre d'enfants
		final int N = 20;
		Thread[] taches = new Thread[N];
		for (int i = 0; i < taches.length; i++) {
			taches[i] = new ThreadMajEnfants("thread n� " + i, service, id3);
			taches[i].start();
		}
		// on attend la fin des threads
		for (int i = 0; i < taches.length; i++) {
			taches[i].join();
		}
		// on r�cup�re la personne
		p3 = service.getOne(id3);
		// elle doit avoir N enfants
		assert N == p3.getNbenfants();
		// suppression personne p1
		service.deleteOne(p3.getId());
		// v�rification
		p3 = service.getOne(p3.getId());
		// on doit avoir un pointeur null
		assert p3 == null;
	}

}
