package tests;

import java.util.Date;

import service.IService;
import entites.Personne;

public class ThreadMajEnfants extends Thread {
	// nom du thread
	private String name;

	// r�f�rence sur la couche [service]
	private IService service;

	// l'id de la personne sur qui on va travailler
	private int idPersonne;

	// constructeur
	public ThreadMajEnfants(String name, IService service, int idPersonne) {
		this.name = name;
		this.service = service;
		this.idPersonne = idPersonne;
	}

	// coeur du thread
	public void run() {
		// suivi
		suivi("lanc�");
		// on boucle tant qu'on n'a pas r�ussi � incr�menter de 1
		// le nbre d'enfants de la personne idPersonne
		boolean fini = false;
		int nbEnfants = 0;
		while (!fini) {
			// on r�cup�re une copie de la personne d'idPersonne
			Personne personne = service.getOne(idPersonne);
			nbEnfants = personne.getNbenfants();
			// suivi
			suivi("" + nbEnfants + " -> " + (nbEnfants + 1) + " pour la version " + personne.getVersion());
			// incr�mente de 1 le nbre d'enfants de cette copie
			personne.setNbenfants(nbEnfants + 1);
			// attente de 10 ms pour abandonner le processeur
			try {
				// suivi
				suivi("d�but attente");
				// on s'interrompt pour laisser le processeur
				Thread.sleep(10);
				// suivi
				suivi("fin attente");
			} catch (Exception ex) {
				throw new RuntimeException(ex.toString());
			}
			// attente termin�e - on essaie de valider la copie
			// entre-temps d'autres threads ont pu modifier l'original
			try {
				// on essaie de modifier l'original
				service.updateOne(personne);
				// on est pass� - l'original a �t� modifi�
				fini = true;
			} catch (RuntimeException e3) {
				// cause de l'exception
				Throwable cause = e3.getCause();
				if (!(cause instanceof org.jboss.tm.JBossRollbackException)
						&& !(cause instanceof javax.persistence.OptimisticLockException)) {
					// si exception pas due au conflit de version, on la remonte
					throw e3;
				}
			}
		}
		// suivi
		suivi("a termin� et pass� le nombre d'enfants � " + (nbEnfants + 1));
	}

	// suivi
	private void suivi(String message) {
		System.out.println(name + " [" + new Date().getTime() + "] : " + message);
	}
}