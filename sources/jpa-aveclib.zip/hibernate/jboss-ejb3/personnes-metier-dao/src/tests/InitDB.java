package tests;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.jboss.ejb3.embedded.EJB3StandaloneBootstrap;

import service.IService;
import entites.Personne;

public class InitDB {

	// couche service
	private static IService service;

	// constructeur
	public static void main(String[] args) throws ParseException, NamingException {
		// on d�marre le conteneur EJB3 JBoss
		// les fichiers de configuration ejb3-interceptors-aop.xml et
		// embedded-jboss-beans.xml sont exploit�s
		EJB3StandaloneBootstrap.boot(null);

		// Cr�ation des beans propres � l'application
		EJB3StandaloneBootstrap.deployXmlResource("META-INF/jboss-config.xml");

		// Deploy all EJBs found on classpath (slow, scans all)
		// EJB3StandaloneBootstrap.scanClasspath();

		// on d�ploie tous les EJB trouv�s dans le classpath de l'application
		EJB3StandaloneBootstrap.scanClasspath("bin".replace("/", File.separator));

		// On initialise le contexte JNDI. Le fichier jndi.properties est exploit�
		InitialContext initialContext = new InitialContext();

		// instanciation couche service
		service = (IService) initialContext.lookup("Service/local");
		// on vide la base
		clean();
		// on la remplit
		fill();
		// on v�rifie visuellement
		dumpPersonnes();
		// on arr�te le conteneur Ejb
		EJB3StandaloneBootstrap.shutdown();
	}

	// affichage contenu table
	private static void dumpPersonnes() {
		System.out
				.format("[personnes]-------------------------------------------------------------------%n");
		for (Personne p : service.getAll()) {
			System.out.println(p);
		}
	}

	// remplissage table
	public static void fill() throws ParseException {
		// cr�ation personnes
		Personne p1 = new Personne("p1", "Paul", new SimpleDateFormat("dd/MM/yy")
				.parse("31/01/2000"), true, 2);
		Personne p2 = new Personne("p2", "Sylvie", new SimpleDateFormat("dd/MM/yy")
				.parse("05/07/2001"), false, 0);
		// qu'on sauvegarde
		service.saveArray(new Personne[] { p1, p2 });
	}

	// supression �l�ments de la table
	public static void clean() {
		for (Personne p : service.getAll()) {
			service.deleteOne(p.getId());
		}
	}
}
