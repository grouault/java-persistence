package service;

import java.util.List;

import entites.Article;
import entites.Categorie;

public interface IService {
	public Article getArticle(Long articleId);

	public List<Article> getAllArticles();

	public Article saveArticle(Article article);

	public Article updateArticle(Article article);

	public void deleteArticle(Long articleId);

	public List<Article> getAllArticlesWithNomLike(String modeleNom);

	public Categorie getCategorie(Long categorieId);

	public List<Categorie> getAllCategories();

	public Categorie saveCategorie(Categorie categorie);

	public Categorie updateCategorie(Categorie categorie);

	public void deleteCategorie(Long categorieId);

	public List<Categorie> getAllCategoriesWithNomLike(String modeleNom);

	public void saveCategoriesWithArticles(Categorie[] categories);

	public void deleteCategoriesWithArticles(Categorie[] categories);

	public List<Article> getArticlesFromCategorie(Long categorieId);
}
