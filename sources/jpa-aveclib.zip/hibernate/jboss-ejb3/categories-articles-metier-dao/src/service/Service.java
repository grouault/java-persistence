package service;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import dao.IDao;
import entites.Article;
import entites.Categorie;

//EJB sans �tat
@Stateless
public class Service implements IService {

	// couche [dao]
	@EJB
	private IDao dao;

	public IDao getDao() {
		return dao;
	}

	public void setDao(IDao dao) {
		this.dao = dao;
	}

	// cat�gories
	public Categorie getCategorie(Long categorieId) {
		return dao.getCategorie(categorieId);
	}

	@SuppressWarnings("unchecked")
	public List<Categorie> getAllCategories() {
		return dao.getAllCategories();
	}

	@SuppressWarnings("unchecked")
	public List<Categorie> getAllCategoriesWithNomLike(String modeleNom) {
		return dao.getAllCategoriesWithNomLike(modeleNom);
	}

	@SuppressWarnings("unchecked")
	public List<Article> getArticlesFromCategorie(Long categorieId) {
		return dao.getArticlesFromCategorie(categorieId);
	}

	public Categorie updateCategorie(Categorie categorie) {
		return dao.updateCategorie(categorie);
	}

	public Categorie saveCategorie(Categorie categorie) {
		return dao.saveCategorie(categorie);
	};

	public void deleteCategorie(Long categorieId) {
		dao.deleteCategorie(categorieId);
	}

	public void saveCategoriesWithArticles(Categorie[] categories) {
		for (Categorie categorie : categories) {
			dao.saveCategorie(categorie);
			for (Article article : categorie.getArticles()) {
				dao.saveArticle(article);
			}
		}
	}

	public void deleteCategoriesWithArticles(Categorie[] categories) {
		for (Categorie categorie : categories) {
			for (Article article : getArticlesFromCategorie(categorie.getId())) {
				dao.deleteArticle(article.getId());
			}
			dao.deleteCategorie(categorie.getId());
		}
	}

	// articles
	public Article getArticle(Long articleId) {
		return dao.getArticle(articleId);
	}

	@SuppressWarnings("unchecked")
	public List<Article> getAllArticles() {
		return dao.getAllArticles();
	}

	@SuppressWarnings("unchecked")
	public List<Article> getAllArticlesWithNomLike(String modeleNom) {
		return dao.getAllArticlesWithNomLike(modeleNom);
	};

	public Article saveArticle(Article article) {
		return dao.saveArticle(article);
	}

	public Article updateArticle(Article article) {
		return dao.updateArticle(article);
	}

	public void deleteArticle(Long articleId) {
		dao.deleteArticle(articleId);
	}

}
