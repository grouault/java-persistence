package tests;

import java.io.File;
import java.text.ParseException;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.jboss.ejb3.embedded.EJB3StandaloneBootstrap;

import service.IService;
import entites.Article;
import entites.Categorie;

public class InitDB {

	// couche service
	private static IService service;

	// constructeur
	public static void main(String[] args) throws ParseException, NamingException {
		// on d�marre le conteneur EJB3 JBoss
		// les fichiers de configuration ejb3-interceptors-aop.xml et embedded-jboss-beans.xml sont exploit�s
		EJB3StandaloneBootstrap.boot(null);

		// Cr�ation des beans propres � l'application
		EJB3StandaloneBootstrap.deployXmlResource("META-INF/jboss-config.xml");

		// Deploy all EJBs found on classpath (slow, scans all)
		// EJB3StandaloneBootstrap.scanClasspath();

		// on d�ploie tous les EJB trouv�s dans le classpath de l'application
		EJB3StandaloneBootstrap.scanClasspath("bin".replace("/", File.separator));

		// On initialise le contexte JNDI. Le fichier jndi.properties est exploit�
		InitialContext initialContext = new InitialContext();

		// instanciation couche service
		service = (IService) initialContext.lookup("Service/local");
		// on vide la base
		clean();
		// on la remplit
		fill();
		// on v�rifie visuellement
		dumpCategories();
		dumpArticles();
	}

	// affichage contenu table categorie
	private static void dumpCategories() {
		System.out.format("[categories]%n");
		for (Categorie c : service.getAllCategories()) {
			System.out.println(c);
		}
	}

	// affichage contenu table Article
	private static void dumpArticles() {
		System.out.format("[articles]%n");
		for (Article a : service.getAllArticles()) {
			System.out.println(a);
		}
	}

	// remplissage tables
	public static void fill() throws ParseException {
		// cr�er trois cat�gories
		Categorie categorieA = new Categorie();
		categorieA.setNom("A");
		Categorie categorieB = new Categorie();
		categorieB.setNom("B");
		Categorie categorieC = new Categorie();
		categorieC.setNom("C");
		// cr�er 3 articles
		Article articleA1 = new Article();
		articleA1.setNom("A1");
		Article articleA2 = new Article();
		articleA2.setNom("A2");
		Article articleB1 = new Article();
		articleB1.setNom("B1");
		// les relier � leur cat�gorie
		articleA1.setCategorie(categorieA);
		categorieA.getArticles().add(articleA1);
		articleA2.setCategorie(categorieA);
		categorieA.getArticles().add(articleA2);
		articleB1.setCategorie(categorieB);
		categorieB.getArticles().add(articleB1);
		// persister les cat�gories et les articles associ�s
		service.saveCategoriesWithArticles(new Categorie[] { categorieA, categorieB, categorieC });
	}

	// supression �l�ments des tables
	public static void clean() {
		// on r�cup�re ttes les cat�gories
		List<Categorie> categories = service.getAllCategories();
		// � partir de l�, on supprime les cat�gories et les articles associ�s
		service.deleteCategoriesWithArticles(categories.toArray(new Categorie[categories.size()]));
	}
}
