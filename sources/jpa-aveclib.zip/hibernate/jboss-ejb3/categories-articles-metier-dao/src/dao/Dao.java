package dao;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entites.Article;
import entites.Categorie;

@Stateless
public class Dao implements IDao {

	@PersistenceContext
	private EntityManager em;

	// cat�gories

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Categorie getCategorie(Long categorieId) {
		return em.find(Categorie.class, categorieId);
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Categorie> getAllCategories() {
		return em.createQuery("select c from Categorie c").getResultList();
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Categorie> getAllCategoriesWithNomLike(String modeleNom) {
		return em.createQuery("select c from Categorie c where c.nom like :modele").setParameter("modele", modeleNom).getResultList();
	}

	@SuppressWarnings("unchecked")
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public List<Article> getArticlesFromCategorie(Long categorieId) {
		return em.createQuery("select a from Article a where a.categorie.id=:categorieId").setParameter("categorieId", categorieId).getResultList();
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Categorie updateCategorie(Categorie categorie) {
		return em.merge(categorie);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Categorie saveCategorie(Categorie categorie) {
		em.persist(categorie);
		return categorie;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void deleteCategorie(Long categorieId) {
		Categorie categorie = em.find(Categorie.class, categorieId);
		if (categorie == null) {
			throw new DaoException(30);
		}
		em.remove(categorie);
	}

	// articles

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Article getArticle(Long articleId) {
		return em.find(Article.class, articleId);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	@SuppressWarnings("unchecked")
	public List<Article> getAllArticles() {
		return em.createQuery("select a from Article a").getResultList();
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	@SuppressWarnings("unchecked")
	public List<Article> getAllArticlesWithNomLike(String modeleNom) {
		return em.createQuery("select a from Article a where a.nom like :modele").setParameter("modele", modeleNom).getResultList();
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Article saveArticle(Article article) {
		em.persist(article);
		return article;
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Article updateArticle(Article article) {
		return em.merge(article);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void deleteArticle(Long articleId) {
		Article article = em.find(Article.class, articleId);
		if (article == null) {
			throw new DaoException(20);
		}
		em.remove(article);
	}
}
